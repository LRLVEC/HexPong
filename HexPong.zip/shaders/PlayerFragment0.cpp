#version 450 core
//flat in vec4 in_color;
out vec4 o_color;
void main()
{
	o_color = vec4(0.8, 0.8, 0.8, 1);
}