#version 450 core
flat in vec4 in_color;
out vec4 o_color;
void main()
{
	o_color = in_color;
}